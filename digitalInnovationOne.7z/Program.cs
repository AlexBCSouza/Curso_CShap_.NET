﻿

int numeroDevezes = 5;

for (int i=0; i < numeroDevezes; i++)
{
    Console.WriteLine($"Welcome to the Course .NET {i}");
}

